// ── login.page.ts ─────────────────────────────────────────────────────────────
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoadingController, ToastController } from '@ionic/angular';
import { AuthService } from '../../core/services/auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
})
export class LoginPage {
  form: FormGroup;
  showPassword = false;

  constructor(
    private fb: FormBuilder,
    private auth: AuthService,
    private router: Router,
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController,
  ) {
    this.form = this.fb.group({
      email:    ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  async onSubmit(): Promise<void> {
    if (this.form.invalid) return;

    const loading = await this.loadingCtrl.create({ message: 'Entrando...' });
    await loading.present();

    this.auth.login(this.form.value).subscribe({
      next: async () => {
        await loading.dismiss();
        this.router.navigateByUrl('/tabs/dashboard', { replaceUrl: true });
      },
      error: async (err: Error) => {
        await loading.dismiss();
        const toast = await this.toastCtrl.create({
          message: err.message,
          duration: 3000,
          color: 'danger',
          position: 'bottom',
        });
        toast.present();
      },
    });
  }
}

// ── login.page.html ───────────────────────────────────────────────────────────
/*
<ion-content class="ion-padding" [fullscreen]="true">
  <div class="login-container">

    <div class="logo-area">
      <div class="logo-icon">
        <ion-icon name="storefront-outline"></ion-icon>
      </div>
      <h1>EasyGest</h1>
      <p>Sistema de gestão empresarial</p>
    </div>

    <form [formGroup]="form" (ngSubmit)="onSubmit()">

      <ion-item>
        <ion-label position="floating">E-mail</ion-label>
        <ion-input
          formControlName="email"
          type="email"
          autocomplete="email"
          inputmode="email">
        </ion-input>
      </ion-item>
      <div class="error-msg" *ngIf="form.get('email')?.touched && form.get('email')?.invalid">
        E-mail inválido
      </div>

      <ion-item>
        <ion-label position="floating">Senha</ion-label>
        <ion-input
          formControlName="password"
          [type]="showPassword ? 'text' : 'password'">
        </ion-input>
        <ion-button fill="clear" slot="end" (click)="showPassword = !showPassword">
          <ion-icon [name]="showPassword ? 'eye-off-outline' : 'eye-outline'"></ion-icon>
        </ion-button>
      </ion-item>

      <ion-button
        expand="block"
        type="submit"
        class="ion-margin-top"
        [disabled]="form.invalid">
        Entrar
      </ion-button>

    </form>

  </div>
</ion-content>
*/

// ── login.module.ts ───────────────────────────────────────────────────────────
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [LoginPage],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    IonicModule,
    RouterModule.forChild([{ path: '', component: LoginPage }]),
  ],
})
export class LoginPageModule {}
