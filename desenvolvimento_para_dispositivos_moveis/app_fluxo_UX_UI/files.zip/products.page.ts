// ── product-list.page.ts ──────────────────────────────────────────────────────
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AlertController, ToastController } from '@ionic/angular';
import { ProductsService } from '../../../core/services/services';
import { Product } from '../../../core/models';

@Component({
  selector: 'app-product-list',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button defaultHref="/tabs/cadastros"></ion-back-button>
        </ion-buttons>
        <ion-title>Produtos</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="router.navigate(['/tabs/cadastros/products/new'])">
            <ion-icon slot="icon-only" name="add-outline"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
      <ion-toolbar>
        <ion-searchbar placeholder="Buscar..." (ionInput)="filter($event)"></ion-searchbar>
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <ion-list>
        <ion-item-sliding *ngFor="let p of filtered">
          <ion-item [routerLink]="['/tabs/cadastros/products', p.id]" detail>
            <ion-label>
              <h2>{{ p.name }}</h2>
              <p>{{ p.sku }} · {{ p.category }}</p>
            </ion-label>
            <div slot="end" class="ion-text-right">
              <p>{{ p.price | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
              <ion-badge [color]="p.stock < 5 ? 'danger' : 'medium'">
                Estq: {{ p.stock }}
              </ion-badge>
            </div>
          </ion-item>

          <ion-item-options side="end">
            <ion-item-option color="danger" (click)="confirmDelete(p)">
              <ion-icon name="trash-outline"></ion-icon>
            </ion-item-option>
          </ion-item-options>
        </ion-item-sliding>
      </ion-list>

      <ion-fab vertical="bottom" horizontal="end" slot="fixed">
        <ion-fab-button [routerLink]="['/tabs/cadastros/products/new']">
          <ion-icon name="add"></ion-icon>
        </ion-fab-button>
      </ion-fab>
    </ion-content>
  `,
})
export class ProductListPage implements OnInit {
  products: Product[] = [];
  filtered: Product[] = [];

  constructor(
    public router: Router,
    private productsService: ProductsService,
    private alertCtrl: AlertController,
    private toastCtrl: ToastController,
  ) {}

  ngOnInit(): void {
    this.productsService.getAll().subscribe(ps => {
      this.products = ps;
      this.filtered = ps;
    });
  }

  filter(event: CustomEvent): void {
    const q = (event.detail.value as string).toLowerCase();
    this.filtered = this.products.filter(p =>
      p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)
    );
  }

  async confirmDelete(p: Product): Promise<void> {
    const alert = await this.alertCtrl.create({
      header: 'Confirmar exclusão',
      message: `Remover "${p.name}"?`,
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Remover', role: 'destructive',
          handler: () => {
            this.productsService.remove(p.id).subscribe(() => {
              this.products = this.products.filter(x => x.id !== p.id);
              this.filtered = this.filtered.filter(x => x.id !== p.id);
              this.toastCtrl.create({
                message: 'Produto removido.', duration: 2000, color: 'success',
              }).then(t => t.present());
            });
          },
        },
      ],
    });
    await alert.present();
  }
}

// ── product-form.page.ts ──────────────────────────────────────────────────────
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { LoadingController } from '@ionic/angular';

@Component({
  selector: 'app-product-form',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-buttons slot="start">
          <ion-back-button defaultHref="/tabs/cadastros/products"></ion-back-button>
        </ion-buttons>
        <ion-title>{{ isEdit ? 'Editar' : 'Novo' }} produto</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <form [formGroup]="form" (ngSubmit)="save()">
        <ion-item>
          <ion-label position="floating">Nome *</ion-label>
          <ion-input formControlName="name"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="floating">SKU *</ion-label>
          <ion-input formControlName="sku" autocapitalize="characters"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label>Categoria</ion-label>
          <ion-select formControlName="category" placeholder="Selecionar">
            <ion-select-option *ngFor="let cat of categories" [value]="cat">{{ cat }}</ion-select-option>
          </ion-select>
        </ion-item>

        <ion-item>
          <ion-label position="floating">Preço (R$) *</ion-label>
          <ion-input formControlName="price" type="number" step="0.01"></ion-input>
        </ion-item>

        <ion-item>
          <ion-label position="floating">Estoque</ion-label>
          <ion-input formControlName="stock" type="number"></ion-input>
        </ion-item>

        <ion-button
          expand="block"
          type="submit"
          class="ion-margin-top"
          [disabled]="form.invalid">
          {{ isEdit ? 'Salvar alterações' : 'Cadastrar produto' }}
        </ion-button>
      </form>
    </ion-content>
  `,
})
export class ProductFormPage implements OnInit {
  form!: FormGroup;
  isEdit = false;
  categories = ['Eletrônicos', 'Periféricos', 'Móveis', 'Áudio', 'Outros'];
  private productId?: number;

  constructor(
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private productsService: ProductsService,
    private loadingCtrl: LoadingController,
    private toastCtrl: ToastController,
  ) {}

  ngOnInit(): void {
    this.form = this.fb.group({
      name:     ['', Validators.required],
      sku:      ['', Validators.required],
      category: ['Eletrônicos', Validators.required],
      price:    [0, [Validators.required, Validators.min(0)]],
      stock:    [0, [Validators.required, Validators.min(0)]],
    });

    const id = this.route.snapshot.paramMap.get('id');
    if (id && id !== 'new') {
      this.isEdit = true;
      this.productId = +id;
      this.productsService.getById(+id).subscribe(p => this.form.patchValue(p));
    }
  }

  async save(): Promise<void> {
    if (this.form.invalid) return;
    const loading = await this.loadingCtrl.create({ message: 'Salvando...' });
    await loading.present();

    const obs = this.isEdit
      ? this.productsService.update(this.productId!, this.form.value)
      : this.productsService.create(this.form.value);

    obs.subscribe({
      next: async () => {
        await loading.dismiss();
        const toast = await this.toastCtrl.create({
          message: `Produto ${this.isEdit ? 'atualizado' : 'cadastrado'}!`,
          duration: 2000, color: 'success',
        });
        toast.present();
        this.router.navigateByUrl('/tabs/cadastros/products');
      },
      error: async (err: Error) => {
        await loading.dismiss();
        const toast = await this.toastCtrl.create({
          message: err.message, duration: 3000, color: 'danger',
        });
        toast.present();
      },
    });
  }
}
