// ════════════════════════════════════════════════════════════════════════════════
// DASHBOARD PAGE
// ════════════════════════════════════════════════════════════════════════════════

import { Component, OnInit } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { SalesService } from '../../core/services/services';
import { FinancialService } from '../../core/services/services';
import { Sale, FinancialSummary } from '../../core/models';

@Component({
  selector: 'app-dashboard',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Olá, {{ auth.currentUser()?.name?.split(' ')[0] }} 👋</ion-title>
        <ion-buttons slot="end">
          <ion-button (click)="auth.logout()">
            <ion-icon slot="icon-only" name="log-out-outline"></ion-icon>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-refresher slot="fixed" (ionRefresh)="load($event)">
        <ion-refresher-content></ion-refresher-content>
      </ion-refresher>

      <!-- Resumo financeiro -->
      <ion-grid>
        <ion-row>
          <ion-col size="6">
            <div class="stat-card success">
              <p class="stat-label">Recebido</p>
              <p class="stat-value">{{ summary?.total_received | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
            </div>
          </ion-col>
          <ion-col size="6">
            <div class="stat-card warning">
              <p class="stat-label">A receber</p>
              <p class="stat-value">{{ summary?.total_pending | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
            </div>
          </ion-col>
          <ion-col size="6">
            <div class="stat-card">
              <p class="stat-label">Vendas</p>
              <p class="stat-value">{{ summary?.sales_count }}</p>
            </div>
          </ion-col>
          <ion-col size="6">
            <div class="stat-card">
              <p class="stat-label">Pendentes</p>
              <p class="stat-value">{{ summary?.pending_count }}</p>
            </div>
          </ion-col>
        </ion-row>
      </ion-grid>

      <!-- Vendas recentes -->
      <ion-list-header>
        <ion-label>Vendas recentes</ion-label>
      </ion-list-header>

      <ion-list lines="full">
        <ion-item *ngFor="let sale of recentSales">
          <ion-label>
            <h2>{{ sale.customer_name }}</h2>
            <p>{{ sale.created_at | date:'dd/MM/yyyy' }}</p>
          </ion-label>
          <div slot="end" class="ion-text-right">
            <p>{{ sale.total | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
            <ion-badge [color]="sale.status === 'pago' ? 'success' : 'warning'">
              {{ sale.status }}
            </ion-badge>
          </div>
        </ion-item>
      </ion-list>
    </ion-content>
  `,
})
export class DashboardPage implements OnInit {
  summary?: FinancialSummary;
  recentSales: Sale[] = [];

  constructor(
    public auth: AuthService,
    private salesService: SalesService,
    private financialService: FinancialService,
  ) {}

  ngOnInit(): void { this.load(); }

  load(event?: unknown): void {
    this.financialService.getSummary().subscribe(s => {
      this.summary = s;
      (event as { target: { complete: () => void } })?.target?.complete();
    });
    this.salesService.getAll().subscribe(sales => {
      this.recentSales = sales.slice(0, 5);
    });
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// SALES PAGE — carrinho + listagem de produtos
// ════════════════════════════════════════════════════════════════════════════════

import { CartService, CustomersService } from '../../core/services/services';
import { ProductsService } from '../../core/services/services';
import { Product, Customer } from '../../core/models';
import { ToastController, LoadingController, AlertController } from '@ionic/angular';

@Component({
  selector: 'app-sales',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Nova venda</ion-title>
        <ion-buttons slot="end">
          <ion-button *ngIf="cart.count() > 0" (click)="openCart()">
            <ion-icon name="cart-outline"></ion-icon>
            <ion-badge color="success">{{ cart.count() }}</ion-badge>
          </ion-button>
        </ion-buttons>
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <ion-searchbar placeholder="Buscar produto..." (ionInput)="filterProducts($event)"></ion-searchbar>

      <ion-grid>
        <ion-row>
          <ion-col size="6" *ngFor="let p of filteredProducts">
            <ion-card (click)="addToCart(p)">
              <ion-card-content>
                <ion-icon name="cube-outline" size="large" color="medium"></ion-icon>
                <p class="product-name">{{ p.name }}</p>
                <p class="product-price">{{ p.price | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
                <ion-badge color="medium">Estq: {{ p.stock }}</ion-badge>

                <!-- Controle de quantidade se já estiver no carrinho -->
                <div *ngIf="getCartQty(p.id) > 0" class="qty-control" (click)="$event.stopPropagation()">
                  <ion-button fill="outline" size="small" (click)="cart.remove(p.id)">−</ion-button>
                  <span>{{ getCartQty(p.id) }}</span>
                  <ion-button fill="outline" size="small" (click)="cart.add(p)">+</ion-button>
                </div>
              </ion-card-content>
            </ion-card>
          </ion-col>
        </ion-row>
      </ion-grid>
    </ion-content>
  `,
})
export class SalesPage implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  customers: Customer[] = [];

  constructor(
    public cart: CartService,
    private productsService: ProductsService,
    private customersService: CustomersService,
    private salesService: SalesService,
    private alertCtrl: AlertController,
    private toastCtrl: ToastController,
    private loadingCtrl: LoadingController,
  ) {}

  ngOnInit(): void {
    this.productsService.getAll().subscribe(p => {
      this.products = p;
      this.filteredProducts = p;
    });
    this.customersService.getAll().subscribe(c => this.customers = c);
  }

  filterProducts(event: CustomEvent): void {
    const q = (event.detail.value as string).toLowerCase();
    this.filteredProducts = this.products.filter(p =>
      p.name.toLowerCase().includes(q) || p.sku.toLowerCase().includes(q)
    );
  }

  addToCart(p: Product): void { this.cart.add(p); }

  getCartQty(productId: number): number {
    return this.cart.cartItems().find(i => i.product.id === productId)?.quantity ?? 0;
  }

  async openCart(): Promise<void> {
    const inputs = this.customers.map(c => ({
      type: 'radio' as const,
      label: `${c.name} (${c.doc_type})`,
      value: c.id,
    }));

    const alert = await this.alertCtrl.create({
      header: `Carrinho — ${this.cart.count()} item(s)`,
      subHeader: `Total: R$ ${this.cart.total().toFixed(2)}`,
      inputs,
      buttons: [
        { text: 'Cancelar', role: 'cancel' },
        {
          text: 'Finalizar venda',
          handler: async (customerId: number) => {
            if (!customerId) return false;
            await this.checkout(customerId);
            return true;
          },
        },
      ],
    });
    await alert.present();
  }

  private async checkout(customerId: number): Promise<void> {
    const loading = await this.loadingCtrl.create({ message: 'Registrando venda...' });
    await loading.present();

    this.salesService.create(this.cart.toDTO(customerId)).subscribe({
      next: async sale => {
        this.cart.clear();
        await loading.dismiss();
        const toast = await this.toastCtrl.create({
          message: `Venda #${sale.id} registrada! Gere o boleto em Financeiro.`,
          duration: 4000, color: 'success',
        });
        toast.present();
      },
      error: async (err: Error) => {
        await loading.dismiss();
        const toast = await this.toastCtrl.create({
          message: err.message, duration: 3000, color: 'danger',
        });
        toast.present();
      },
    });
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// FINANCIAL PAGE
// ════════════════════════════════════════════════════════════════════════════════

@Component({
  selector: 'app-financial',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Financeiro</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content class="ion-padding">
      <ion-grid *ngIf="summary">
        <ion-row>
          <ion-col size="6">
            <div class="stat-card success">
              <p class="stat-label">Recebido</p>
              <p class="stat-value">{{ summary.total_received | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
            </div>
          </ion-col>
          <ion-col size="6">
            <div class="stat-card warning">
              <p class="stat-label">A receber</p>
              <p class="stat-value">{{ summary.total_pending | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
            </div>
          </ion-col>
        </ion-row>
      </ion-grid>

      <ion-list-header><ion-label>Lançamentos</ion-label></ion-list-header>
      <ion-list>
        <ion-item *ngFor="let sale of sales" [detail]="sale.status === 'pendente'">
          <ion-label>
            <h2>{{ sale.customer_name }}</h2>
            <p>{{ sale.created_at | date:'dd/MM/yyyy' }} · Venda #{{ sale.id }}</p>
          </ion-label>
          <div slot="end" class="ion-text-right">
            <p>{{ sale.total | currency:'BRL':'symbol':'1.2-2':'pt' }}</p>
            <ion-badge [color]="sale.status === 'pago' ? 'success' : sale.status === 'cancelado' ? 'medium' : 'warning'">
              {{ sale.status }}
            </ion-badge>
            <ion-button *ngIf="sale.status === 'pendente'" fill="outline" size="small"
              (click)="openBoleto(sale.id)">
              Boleto
            </ion-button>
          </div>
        </ion-item>
      </ion-list>
    </ion-content>
  `,
})
export class FinancialPage implements OnInit {
  summary?: FinancialSummary;
  sales: Sale[] = [];

  constructor(
    private financialService: FinancialService,
    private salesService: SalesService,
    private alertCtrl: AlertController,
    private toastCtrl: ToastController,
  ) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.financialService.getSummary().subscribe(s => this.summary = s);
    this.salesService.getAll().subscribe(s => this.sales = s);
  }

  async openBoleto(saleId: number): Promise<void> {
    this.financialService.getBoleto(saleId).subscribe(async boleto => {
      const alert = await this.alertCtrl.create({
        header: `Boleto #${boleto.boleto_number}`,
        message: `
          <strong>Pagador:</strong> ${boleto.payer_name}<br>
          <strong>Doc:</strong> ${boleto.payer_doc}<br>
          <strong>Valor:</strong> R$ ${boleto.amount.toFixed(2)}<br>
          <strong>Vencimento:</strong> ${new Date(boleto.due_date).toLocaleDateString('pt-BR')}<br>
          <br>
          <small>${boleto.barcode}</small>
        `,
        buttons: [
          { text: 'Fechar' },
          {
            text: 'Marcar como pago',
            handler: () => {
              this.salesService.updateStatus(saleId, 'pago').subscribe(() => {
                this.load();
                this.toastCtrl.create({
                  message: 'Venda marcada como paga!', duration: 2000, color: 'success',
                }).then(t => t.present());
              });
            },
          },
        ],
      });
      await alert.present();
    });
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// CADASTROS PAGE — menu para Produtos / Clientes / Usuários
// ════════════════════════════════════════════════════════════════════════════════

import { Router } from '@angular/router';

@Component({
  selector: 'app-cadastros',
  template: `
    <ion-header>
      <ion-toolbar>
        <ion-title>Cadastros</ion-title>
      </ion-toolbar>
    </ion-header>

    <ion-content>
      <ion-list>
        <ion-item button (click)="go('products')" detail>
          <ion-icon name="cube-outline" slot="start" color="primary"></ion-icon>
          <ion-label>
            <h2>Produtos</h2>
            <p>Estoque e preços</p>
          </ion-label>
        </ion-item>

        <ion-item button (click)="go('customers')" detail>
          <ion-icon name="people-outline" slot="start" color="tertiary"></ion-icon>
          <ion-label>
            <h2>Clientes</h2>
            <p>CPF e CNPJ</p>
          </ion-label>
        </ion-item>

        <ion-item button (click)="go('users')" detail *ngIf="auth.hasRole('admin')">
          <ion-icon name="shield-outline" slot="start" color="warning"></ion-icon>
          <ion-label>
            <h2>Usuários</h2>
            <p>Perfis de acesso</p>
          </ion-label>
        </ion-item>
      </ion-list>
    </ion-content>
  `,
})
export class CadastrosPage {
  constructor(
    public auth: AuthService,
    private router: Router,
  ) {}

  go(page: string): void {
    this.router.navigateByUrl(`/tabs/cadastros/${page}`);
  }
}
