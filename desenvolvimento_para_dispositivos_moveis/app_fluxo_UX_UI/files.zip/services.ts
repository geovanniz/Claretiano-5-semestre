// ── products.service.ts ───────────────────────────────────────────────────────
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ApiService } from './api.service';
import { Product, CreateProductDTO } from '../models';

@Injectable({ providedIn: 'root' })
export class ProductsService {
  constructor(private api: ApiService) {}

  getAll(): Observable<Product[]>                              { return this.api.get('/products'); }
  getById(id: number): Observable<Product>                     { return this.api.get(`/products/${id}`); }
  create(dto: CreateProductDTO): Observable<Product>           { return this.api.post('/products', dto); }
  update(id: number, dto: Partial<CreateProductDTO>): Observable<Product> { return this.api.put(`/products/${id}`, dto); }
  remove(id: number): Observable<void>                         { return this.api.delete(`/products/${id}`); }
}

// ── customers.service.ts ──────────────────────────────────────────────────────
import { Customer, CreateCustomerDTO } from '../models';

@Injectable({ providedIn: 'root' })
export class CustomersService {
  constructor(private api: ApiService) {}

  getAll(): Observable<Customer[]>                                    { return this.api.get('/customers'); }
  getById(id: number): Observable<Customer>                           { return this.api.get(`/customers/${id}`); }
  create(dto: CreateCustomerDTO): Observable<Customer>                { return this.api.post('/customers', dto); }
  update(id: number, dto: Partial<CreateCustomerDTO>): Observable<Customer> { return this.api.put(`/customers/${id}`, dto); }
  remove(id: number): Observable<void>                                { return this.api.delete(`/customers/${id}`); }
}

// ── users.service.ts ──────────────────────────────────────────────────────────
import { User, CreateUserDTO } from '../models';

@Injectable({ providedIn: 'root' })
export class UsersService {
  constructor(private api: ApiService) {}

  getAll(): Observable<User[]>                                        { return this.api.get('/users'); }
  create(dto: CreateUserDTO): Observable<User>                        { return this.api.post('/users', dto); }
  update(id: number, dto: Partial<CreateUserDTO>): Observable<User>   { return this.api.put(`/users/${id}`, dto); }
  deactivate(id: number): Observable<void>                            { return this.api.delete(`/users/${id}`); }
}

// ── sales.service.ts ──────────────────────────────────────────────────────────
import { Sale, CreateSaleDTO } from '../models';

@Injectable({ providedIn: 'root' })
export class SalesService {
  constructor(private api: ApiService) {}

  getAll(): Observable<Sale[]>                                        { return this.api.get('/sales'); }
  getById(id: number): Observable<Sale>                               { return this.api.get(`/sales/${id}`); }
  create(dto: CreateSaleDTO): Observable<Sale>                        { return this.api.post('/sales', dto); }
  updateStatus(id: number, status: Sale['status']): Observable<Sale>  { return this.api.patch(`/sales/${id}/status`, { status }); }
}

// ── financial.service.ts ──────────────────────────────────────────────────────
import { FinancialSummary, Boleto } from '../models';

@Injectable({ providedIn: 'root' })
export class FinancialService {
  constructor(private api: ApiService) {}

  getSummary(): Observable<FinancialSummary>    { return this.api.get('/financial/summary'); }
  getBoleto(saleId: number): Observable<Boleto> { return this.api.get(`/financial/boleto/${saleId}`); }
}

// ── cart.service.ts — estado local do carrinho ────────────────────────────────
import { signal, computed } from '@angular/core';
import { CartItem, Product } from '../models';

@Injectable({ providedIn: 'root' })
export class CartService {
  private items = signal<CartItem[]>([]);

  readonly cartItems = this.items.asReadonly();

  readonly total = computed(() =>
    this.items().reduce((sum, i) => sum + i.product.price * i.quantity, 0)
  );

  readonly count = computed(() =>
    this.items().reduce((sum, i) => sum + i.quantity, 0)
  );

  add(product: Product): void {
    const current = this.items();
    const idx = current.findIndex(i => i.product.id === product.id);
    if (idx >= 0) {
      const updated = [...current];
      updated[idx] = { ...updated[idx], quantity: updated[idx].quantity + 1 };
      this.items.set(updated);
    } else {
      this.items.set([...current, { product, quantity: 1 }]);
    }
  }

  remove(productId: number): void {
    const current = this.items();
    const idx = current.findIndex(i => i.product.id === productId);
    if (idx < 0) return;
    const item = current[idx];
    if (item.quantity > 1) {
      const updated = [...current];
      updated[idx] = { ...item, quantity: item.quantity - 1 };
      this.items.set(updated);
    } else {
      this.items.set(current.filter((_, i) => i !== idx));
    }
  }

  clear(): void {
    this.items.set([]);
  }

  toDTO(customerId: number, notes?: string): import('../models').CreateSaleDTO {
    return {
      customer_id: customerId,
      items: this.items().map(i => ({ product_id: i.product.id, quantity: i.quantity })),
      notes,
    };
  }
}
